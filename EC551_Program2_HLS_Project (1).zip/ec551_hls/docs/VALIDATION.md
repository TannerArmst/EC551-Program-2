# Validation record

Executed in a Linux environment with Python 3.12.14, Icarus Verilog 12.0, and Yosys 0.33. Use `python3 --version` locally; Python 3.10 or newer is supported.

## Checks actually executed

| Check | Result |
|---|---|
| Nine Python unittest methods | PASS |
| 120 random source programs × five scheduling modes, independently evaluated and schedule/binding checked | PASS (600 schedules) |
| Five supplied programs × five modes | PASS (25 RTL simulations) |
| Eight random 20-equation programs × five modes | PASS (40 RTL simulations) |
| Padded constrained ALAP bound | PASS (one RTL simulation) |
| RTL widths covered | 4, 8, 16, 32, 64 |
| Generated RTL total | 66 simulations, each with directed and seeded random transactions |
| All eight committed example builds, full default 27-vector testbenches | PASS |
| Board runtime with short debounce for simulation | PASS: startup, bounce, held buttons, input capture, manual step, run, observation selectors, reset, restart |
| Nexys 3 and Nexys A7 top-level elaboration | PASS |
| Generic Yosys synthesis: `hls_core` | PASS, zero structural check failures |
| Generic Yosys synthesis: `nexys3_top` | PASS, zero structural check failures |
| Generic Yosys synthesis: `nexys_a7_top` | PASS, zero structural check failures |

Each RTL simulation checks every SSA result and each shared FU's last committed output after each scheduled cycle, as well as final output lanes, stalls, input snapshot, ignored start while busy, completion, reset and restart. Random arithmetic may wrap intentionally under the documented unsigned W-bit semantics.

Commands:

```sh
python3 scripts/verify.py --require-rtl
python3 scripts/check_synthesis.py build/demo
python3 scripts/check_synthesis.py build/demo --top nexys3_top
python3 scripts/check_synthesis.py build/demo --top nexys_a7_top
```

The verifier's terminal summary:

```text
PASS: Python tests, 66 generated RTL simulations, board integration, both board wrappers
```

The committed example generator was also run, and the sharing example's reference values were checked with A=5, B=3, C=2, D=1.

## Checks not executed

No physical FPGA was connected. Xilinx ISE and Vivado were not installed. The board constraints and vendor build/program scripts are provided but have not been exercised through the Xilinx toolchains here. Consequently there is no claim of device-specific synthesis, placed/routed timing closure, successful programming, electrical correctness, measured build time, or completion of the live demonstration. Generic synthesis does not establish those results.

Pins were checked against the manufacturer references linked in README; that does not replace testing on the user's actual board revision.

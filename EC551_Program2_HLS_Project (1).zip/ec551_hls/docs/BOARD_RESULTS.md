# Physical FPGA results — fill after actual testing

Status: **not yet performed in this environment**.

| Item | Measured result |
|---|---|
| Board model and PCB revision | Pending |
| FPGA device / package / speed | Pending |
| Xilinx tool version and OS | Pending |
| Equation file and source commit | Pending |
| Scheduling mode / limits / width | Pending |
| Synthesis result | Pending |
| Placement / routing result | Pending |
| Setup / hold slack and unconstrained paths | Pending |
| LUT / register / DSP utilization | Pending |
| Full generate/simulate/build/program time | Pending |
| Programmed bitstream identity | Pending |
| Actual switches and expected/observed outputs | Pending |
| One press = one computation cycle | Pending |
| Every FU selectable and visible | Pending |
| Reset / restart verified | Pending |
| Evidence (photo / video / report files) | Pending |

Rehearse three fresh, professor-style custom equation compilations. Each six-minute live slot allows at most four minutes for hardware build/program plus two for input editing and output inspection. If the actual build cannot meet this budget, resolve the demo workflow with the professor before the presentation.
